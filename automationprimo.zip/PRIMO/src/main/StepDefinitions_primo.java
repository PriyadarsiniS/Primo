package main;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Wait;

import com.perfectomobile.selenium.MobileDriver;
import com.perfectomobile.selenium.api.IMobileDevice;
import com.perfectomobile.selenium.api.IMobileWebDriver;
//import com.perfectomobile.selenium.options.MobileDeviceFindOptions;
//import com.perfectomobile.selenium.options.MobileDeviceProperty;
import com.perfectomobile.selenium.by.ByMobile;
import com.perfectomobile.selenium.options.visual.MobileShiftOptions;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions_primo {

	MobileDriver iosdriver, anddriver;
	IMobileDevice iosdevice, anddevice;
	IMobileWebDriver iosprimo, andprimo, iosvisprimo, andvisprimo;
	
	String iOSDeviceID="8CF6ACC702ACE01E3060795C929BCD8064333035";
	String andDeviceID="02157DF2D1A60F27";
	

	
	@Before
	public void before(){
			
		//MobileProxy proxy = new MobileProxy("proxy.tcs.com", 8080, "582433", "Roshan1!");
		//System.out.println("Proxy setting done...");
								
		//DesiredCapabilities capabilities = new DesiredCapabilities();
		//capabilities.setCapability(CapabilityType.PROXY, proxy);
		
		
/*iOS Mobile Driver Declaration*/
		
		iosdriver = new MobileDriver();	
		//options.setManufacturer("Apple");
		//options.setModel("iPhone-6S");
		//options.setOS(MobileDeviceOS.iOS);
		//options.setOSVersion("9.1");
		//options.setResolution("750*1334");
		//iosdevice = iosdriver.findDevice(options);
		
		iosdevice = iosdriver.getDevice(iOSDeviceID);
		iosprimo= iosdevice.getNativeDriver();
		iosvisprimo =iosdevice.getVisualDriver();
		

/*Android Mobile Driver Declaration*/		
		
		anddriver = new MobileDriver();
		//options.setManufacturer("Motorola");
		//options.setModel("Moto G");
		//options.setOS(MobileDeviceOS.ANDROID);
		//options.setOSVersion("6.0");
		//options.setResolution("720*1280");
		//anddevice = anddriver.findDevice(options);
		
		anddevice = anddriver.getDevice(andDeviceID);
		andprimo= anddevice.getNativeDriver();
		andvisprimo =anddevice.getVisualDriver();
		
	}
	
/*
	@After
	public void after(){
				
//iOS Primo SignOut Method//		
		
		//iosprimo.findElement(By.name("NavigationBarBack")).click();
		//System.out.println("Clicked on back button");
		//iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Menu")).click();
		System.out.println("Clicked on iOS-PRIMO Navigation icon");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
	
		iosprimo.findElement(By.name("My Account")).click();
		System.out.println("Now in iOS-PRIMO My Accounts Menus");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
	
		iosprimo.findElement(By.name("Sign Out")).click();
		System.out.println("Clicked on Sign Out in iOS-PRIMO  My Accounts");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Log Out")).click();
		System.out.println("Logged Out from iOS-PRIMO application successfully");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
//Android Primo SignOut Method//
		
		andprimo.findElement(By.xpath("//*[@class='android.widget.ImageButton']")).click();
		System.out.println("Clicked on Android-PRIMO Navigation icon");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.linkText("My Account")).click();
		System.out.println("Now in Android-PRIMO My Accounts Menus");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.linkText("Sign Out")).click();
		System.out.println("Signed Out from Android-PRIMO application successfully");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		//driver.quit();
		
	}
*/

	
	
/*iOS Primo SignIn Method*/	
	
	@Given("^I am launching the iOS device with DeviceID$")
	public void i_am_launching_the_iOS_device_with_DeviceID() throws Throwable {
	   
		//iosdevice = iosdriver.getDevice(iOSDeviceID);
		System.out.println("iOS Device identified by device ID");
		//System.out.println("iOS device ID =" + iOSDeviceID);
		//OStype = iosdevice.getProperty(MobileDeviceProperty.OS);
		//System.out.println("OS type : " + OStype);

	}

	
	@And("^I am opening the iOS device and navigating to home screen$")
	public void i_am_opening_the_iOS_device_and_navigating_to_home_screen() throws Throwable {
	    
		//iosdevice.open();
		System.out.println("iOS device opened successfully");
		//iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		

		//iosdevice.home();
		System.out.println("Now in iOS device Home screen");
		//iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
				
	}

	
	@When("^I launch the iOS-PRIMO application and land on iOS-PRIMO Welcome Page$")
	public void i_launch_the_iOS_PRIMO_application_and_land_on_iOS_PRIMO_Welcome_Page() throws Throwable {
	   
		iosprimo = iosdevice.getNativeDriver("Primo");
		iosprimo.open();
		System.out.println("iOS-PRIMO launched successfully");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		System.out.println("Now in iOS-PRIMO welcome page");
		
	}

		
	@And("^I navigate to the iOS-PRIMO Login Page$")
	public void i_navigate_to_the_iOS_PRIMO_Login_Page() throws Throwable {
	    
		iosprimo.findElement(By.xpath("//*[text()=\"SIGN IN\"]")).click();
		System.out.println("Clicked on SIGN IN button in iOS-PRIMO welcome page");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		System.out.println("Now in iOS-PRIMO login page");
		
	}

	
	@Then("^I enter the valid iOS-PRIMO login credentials \"([^\"]*)\", \"([^\"]*)\"$")
	public void i_enter_the_valid_iOS_PRIMO_login_credentials(String iOSUsername, String iOSPassword) throws Throwable {
	   
		iosprimo.findElement(By.xpath("//*[text()=\"Username\"]")).sendKeys(iOSUsername);
		System.out.println("Entered iOS-PRIMO Username : " + iOSUsername);
		
		iosprimo.findElement(By.xpath("//*[text()=\"Password\"]")).sendKeys(iOSPassword);
		System.out.println("Entered iOS-PRIMO Password : " + iOSPassword);
		
	}

	
	@And("^I logged into iOS-PRIMO application successfully and land on Recents Screen$")
	public void i_logged_into_iOS_PRIMO_application_successfully_and_land_on_Recents_Screen() throws Throwable {
	    
		iosprimo.findElement(By.name("Login")).click();
		System.out.println("Clicked on SIGN IN button in iOS-PRIMO Login page");
		System.out.println("Logged into iOS-PRIMO application successfully");
		System.out.println("Now in iOS-PRIMO Recents Screen");
		
	}
	
	
	
/*Android Primo SignIn Method*/	
	
	@Given("^I am launching the android device with DeviceID$")
	public void i_am_launching_the_android_device_with_DeviceID() throws Throwable {
	   	
		//anddevice = anddriver.getDevice(andDeviceID);
		System.out.println("Android Device identified by device ID");
		//System.out.println("Android device ID = " + andDeviceID);
		//OStype = anddevice.getProperty(MobileDeviceProperty.OS);
		//System.out.println("OS type : " + OStype);
		
	}

	
	@And("^I am opening the android device and navigating to home screen$")
	public void i_am_opening_the_android_device_and_navigating_to_home_screen() throws Throwable {
	 
		//anddevice.open();
		System.out.println("Android device opened successfully");
		//natdriver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			

		//anddevice.home();
		System.out.println("Now in Android device home screen");
		//natdriver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			
	}

	
	@When("^I launch the android-PRIMO application and land on android-PRIMO Welcome Page$")
	public void i_launch_the_android_PRIMO_application_and_land_on_android_PRIMO_Welcome_Page() throws Throwable {
	
		andprimo = anddevice.getNativeDriver("Primo");
		andprimo.open();
		System.out.println("Android-PRIMO launched successfully");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		System.out.println("Now in Android-PRIMO welcome page");	
		
	}

	
	@And("^I navigate to the android-PRIMO Login Page$")
	public void i_navigate_to_the_android_PRIMO_Login_Page() throws Throwable {
	
		andprimo.findElement(By.xpath("//*[text()=\"SIGN IN\"]")).click();
		System.out.println("Clicked on SIGN IN button in Android-PRIMO welcome page");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		System.out.println("Now in Android-PRIMO login page");
		
	}

	
	@Then("^I enter the valid android-PRIMO login credentials \"([^\"]*)\", \"([^\"]*)\"$")
	public void i_enter_the_valid_android_PRIMO_login_credentials(String andUsername, String andPassword) throws Throwable {
	   
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/editTextUsername")).sendKeys(andUsername);
		System.out.println("Entered Android-PRIMO Username : " + andUsername);
			
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/editTextPassword")).sendKeys(andPassword);
		System.out.println("Entered Android-PRIMO Password : " + andPassword);
		
	}


	@Then("^I logged into android-PRIMO application successfully and land on Recents Screen$")
	public void i_logged_into_android_PRIMO_application_successfully_and_land_on_Recents_Screen() throws Throwable {
	    
		andprimo.findElement(By.xpath("//*[text()=\"LOGIN\"]")).click();
		System.out.println("Clicked on SIGN IN button in Android-PRIMO Login page");
		System.out.println("Logged into Android-PRIMO successfully");
		System.out.println("Now in Android-PRIMO Recents Screen");
		
	}
	

	
/*iOS to Android IM methods*/
	
	@Given("^I am navigating to iOS-PRIMO Message window from the left slide out main menu$")
	public void i_am_navigating_to_iOS_PRIMO_Message_window_from_the_left_slide_out_main_menu() throws Throwable {
		
		iosprimo.findElement(By.name("Menu")).click();
		System.out.println("Clicked on iOS-PRIMO Navigation icon");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		//iosprimo.findElement(By.name("Message")).click();
		iosprimo.findElement(By.name("Contacts")).click();
		System.out.println("Now in iOS-PRIMO Contacts Tab");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@And("^I am searching and navigating to Android-PRIMO user \"([^\"]*)\"$")
	public void i_am_searching_and_navigating_to_Android_PRIMO_user(String andUsername) throws Throwable {
	   
		//iosprimo.findElement(By.xpath("//*[@value=\"Enter Name or Number\"]")).sendKeys(andUsername);
		//System.out.println("Searched android user : " + andUsername);
		//iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Mythili Panekatt")).click();
		System.out.println("Now in selected Android user's " + andUsername  + "iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@Then("^I am navigating to the Android-PRIMO Message Window from left slide out main menu$")
	public void i_am_navigating_to_the_Android_PRIMO_Message_Window_from_left_slide_out_main_menu() throws Throwable {
	  
		andprimo.findElement(By.xpath("//*[@class='android.widget.ImageButton']")).click();
		System.out.println("Clicked on Android-PRIMO Navigation icon");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			
		//andprimo.findElement(By.linkText("Message")).click();
		andprimo.findElement(By.linkText("Contacts")).click();
		System.out.println("Now in Android-PRIMO Contacts Tab");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@And("^I am searching and navigating to iOS-PRIMO user \"([^\"]*)\"$")
	public void i_am_searching_and_navigating_to_iOS_PRIMO_user(String iOSUsername) throws Throwable {
	   
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/menu_search")).click();
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/search_src_text")).sendKeys(iOSUsername);
		System.out.println("Searched iOS user : " + iOSUsername);
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			
		//andprimo.findElement(By.xpath("(//*[@resourceid='com.primo.mobile.android.app:id/text1'])[2]")).click();
		andprimo.findElement(By.xpath("(//*[@resourceid='com.primo.mobile.android.app:id/text1'])")).click();
		System.out.println("Now in selected iOS user's " + iOSUsername + " Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
/*Android Chat History deletion method*/
	
	@Then("^I am deleting the chat history of iOS-PRIMO user \"([^\"]*)\" in Android device$")
	public void i_am_deleting_the_chat_history_of_iOS_PRIMO_user_in_Android_device(String iOSUsername) throws Throwable {
	   	
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_options_open")).click();
		System.out.println("Clicked on the options button in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_more_options")).click();
		System.out.println("Clicked on the more options button in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/delete_history_textview")).click();
		System.out.println("Selected delete history in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		System.out.println("Deleted iOS user " + iOSUsername + " chat history in Android device successfully");
		
	}

	
/*iOS to Android IM method*/
	
	@When("^I am sending the iOS-PRIMO IM \"([^\"]*)\" to Android user \"([^\"]*)\" from iOS device$")
	public void i_am_sending_the_iOS_PRIMO_IM_to_Android_user_from_iOS_device(String iOSIMtext, String andUsername) throws Throwable {
		
		iosprimo.findElement(By.xpath("//*[@value=\"Enter text\"]")).sendKeys(iOSIMtext);
		System.out.println("Entered iOS-IM : " + iOSIMtext);
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("ChatSend")).click();
		System.out.println("iOS-IM sent to android user " + andUsername + " successfully");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
/*iOS to Android Ping method*/
	
	@And("^I am sending the iOS-PRIMO Ping to Android user \"([^\"]*)\" from iOS device$")
	public void i_am_sending_the_iOS_PRIMO_Ping_to_Android_user_from_iOS_device(String andUsername) throws Throwable {
	    
		iosprimo.findElement(By.name("ChatOptions")).click();
		System.out.println("Clicked on the options button in iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("ChatOptionPing")).click();
		System.out.println("Ping sent to android user" + andUsername + "successfully");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
/*iOS to Android File Sharing method*/
	
	@And("^I am sending the iOS-PRIMO File to Android user \"([^\"]*)\" from iOS device$")
	public void i_am_sending_the_iOS_PRIMO_File_to_Android_user_from_iOS_device(String andUsername) throws Throwable {
	    
		iosprimo.findElement(By.name("ChatOptions")).click();
		System.out.println("Clicked on the options button in iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("ChatOptionAttach")).click();
		System.out.println("Clicked on the attach option in iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Photo Library")).click();
		System.out.println("Navigated to iOS-Photo Library");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.xpath("//*[@path=\"/0/0/1/1/0\"]")).click();
		System.out.println("Selected Image from iOS-Photo Library");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Done")).click();
		System.out.println("Confirmed the selected Image in iOS-Photo Library");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		System.out.println("File sent to Android user " + andUsername + " successfully");
		
	}
	
	
/*iOS to Android IM Check method*/
	
	@Then("^I am checking in the iOS-PRIMO user \"([^\"]*)\" Android-PRIMO Message window for the sent iOS-PRIMO-IM \"([^\"]*)\"$")
	public void i_am_checking_in_the_iOS_PRIMO_user_Android_PRIMO_Message_window_for_the_sent_iOS_PRIMO_IM(String iOSIMtext, String iOSUsername) throws Throwable {
	   
		try{
			
			boolean IMandroidtextpresence = andprimo.findElement(By.name(iOSIMtext)).isDisplayed();
		
			if(IMandroidtextpresence){
			
				System.out.println("IM from iOS user : " + iOSUsername + " received successfully");
		
			}
		}
		
			catch(org.openqa.selenium.NoSuchElementException e){
		
				System.out.println(e);
				System.out.println("IM from iOS user : " + iOSUsername + " not received");
		
			}
		
	}
	
	
/*iOS to Android Ping Check method*/
	
	@And("^I am checking in the iOS-PRIMO user \"([^\"]*)\" Android-PRIMO Message window for the sent iOS-PRIMO-Ping$")
	public void i_am_checking_in_the_iOS_PRIMO_user_Android_PRIMO_Message_window_for_the_sent_iOS_PRIMO_Ping(String iOSUsername) throws Throwable {
	    
		try{
			
			boolean IMandroidPingpresence = andprimo.findElement(By.xpath("//*[contains(text(), 'sanity one pinged you')]")).isDisplayed();
		
			if(IMandroidPingpresence){
			
				System.out.println("Ping sent by " + iOSUsername + " received successfully");
		
			}
		}
		
			catch(org.openqa.selenium.NoSuchElementException e){
		
				System.out.println(e);
				System.out.println("Ping sent by " + iOSUsername + " not received");
		
			}
		
	}

	
/*iOS to Android File Sharing Check method*/
	
	@And("^I am checking in the iOS-PRIMO user \"([^\"]*)\" Android-PRIMO Message window for the sent iOS-PRIMO-File$")
	public void i_am_checking_in_the_iOS_PRIMO_user_Android_PRIMO_Message_window_for_the_sent_iOS_PRIMO_File(String iOSUsername) throws Throwable {
	 
		try{
			
			boolean IMandroidFilepresence = andprimo.findElement(By.id("com.primo.mobile.android.app:id/messageImagePreview")).isDisplayed();
		
			if(IMandroidFilepresence){
			
				System.out.println("File sent by iOS user " + iOSUsername + " received successfully");
		
			}
	
		}
		
			catch(org.openqa.selenium.NoSuchElementException e){
		
				System.out.println(e);
				System.out.println("File sent by iOS user " + iOSUsername + " not received");
		
			}
		
	}
	
	
/*Android to iOS Chat methods*/
	
	@Given("^I am navigating to Android-PRIMO Message window from the left slide out main menu$")
	public void i_am_navigating_to_Android_PRIMO_Message_window_from_the_left_slide_out_main_menu() throws Throwable {
	 
		andprimo.findElement(By.xpath("//*[@class='android.widget.ImageButton']")).click();
		System.out.println("Clicked on Android-PRIMO Navigation icon");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			
		//andprimo.findElement(By.linkText("Message")).click();
		andprimo.findElement(By.linkText("Contacts")).click();
		System.out.println("Now in Android-PRIMO Contacts Tab");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@Then("^I am navigating to the iOS-PRIMO Message Window from left slide out main menu$")
	public void i_am_navigating_to_the_iOS_PRIMO_Message_Window_from_left_slide_out_main_menu() throws Throwable {
	
		iosprimo.findElement(By.name("Menu")).click();
		System.out.println("Clicked on iOS-PRIMO Navigation icon");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		//iosprimo.findElement(By.name("Message")).click();
		iosprimo.findElement(By.name("Contacts")).click();
		System.out.println("Now in iOS-PRIMO Contacts Tab");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
/*iOS Chat History deletion method*/
	
	@Then("^I am deleting the chat history of Android-PRIMO user \"([^\"]*)\" in iOS device$")
	public void i_am_deleting_the_chat_history_of_Android_PRIMO_user_in_iOS_device(String andUsername) throws Throwable {
	    
		iosprimo.findElement(By.name("ChatOptions")).click();
		System.out.println("Clicked on the options button in iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("ChatOptionMore")).click();
		System.out.println("Clicked on the more options button in iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Delete History")).click();
		System.out.println("Selected delete history in iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		System.out.println("Deleted Android user" + andUsername + "chat history in iOS device successfully");

		iosprimo.findElement(By.name("Mythili Panekatt")).click();
		System.out.println("Now in selected Android user's " + andUsername  + "iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
/*Android to iOS IM method*/
	
	@When("^I am sending the Android-PRIMO IM \"([^\"]*)\" to iOS user \"([^\"]*)\" from Android device$")
	public void i_am_sending_the_Android_PRIMO_IM_to_iOS_user_from_Android_device(String andIMtext, String iOSUsername) throws Throwable {
	   
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/edit_text_message")).sendKeys(andIMtext);
		System.out.println("Entered Android-IM : " + andIMtext);
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_send_message")).click();
		System.out.println("Android-IM sent to iOS user " + iOSUsername +" successfully");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
/*Android to iOS Ping method*/
	
	@And("^I am sending the Android-PRIMO Ping to iOS user \"([^\"]*)\" from Android device$")
	public void i_am_sending_the_Android_PRIMO_Ping_to_iOS_user_from_Android_device(String iOSUsername) throws Throwable {
	    
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_options_open")).click();
		System.out.println("Clicked on the options button in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_send_ping")).click();
		System.out.println("Ping sent to iOS user " + iOSUsername + " successfully");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
/*Android to iOS File Sharing method*/
	
	@And("^I am sending the Android-PRIMO File to iOS user \"([^\"]*)\" from Android device$")
	public void i_am_sending_the_Android_PRIMO_File_to_iOS_user_from_Android_device(String iOSUsername) throws Throwable {
	    
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_options_open")).click();
		System.out.println("Clicked on the options button in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_send_file")).click();
		System.out.println("Clicked on the attach option in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.linkText("Send file")).click();
		andprimo.findElement(By.xpath("//device/view/group[1]/group[1]/group[1]/view[1]/group[1]/view[1]/button[1]")).click();
		andprimo.findElement(By.linkText("Gallery")).click();
		System.out.println("Navigated to Android-Gallery");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.xpath("//*[@class='com.sec.samsung.gallery.glview.composeView.PositionControllerBase$ThumbObject'][3]")).click();
		System.out.println("Selected Image from Android-Gallery");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		System.out.println("File sent to iOS user " + iOSUsername + " successfully");
		
	}


/*Android to iOS IM Check method*/
	
	@Then("^I am checking in the Android-PRIMO user \"([^\"]*)\" iOS-PRIMO Message window for the sent Android-PRIMO-IM \"([^\"]*)\"$")
	public void i_am_checking_in_the_Android_PRIMO_user_iOS_PRIMO_Message_window_for_the_sent_Android_PRIMO_IM(String andIMtext, String andUsername) throws Throwable {
	    
		try{
			
			boolean IMiOStextpresence = iosprimo.findElement(By.xpath("//*[contains(text(), 'Hello_iOS')]")).isDisplayed();
		
			if(IMiOStextpresence){
			
				System.out.println("IM sent by android user " + andUsername + " received successfully");
		
			}
		}
		
			catch(org.openqa.selenium.NoSuchElementException e){
		
				System.out.println(e);
				System.out.println("IM sent by android user " + andUsername + " not received");
		
			}
		
	}

	
/*Android to iOS Ping Check method*/
	
	@And("^I am checking in the Android-PRIMO user \"([^\"]*)\" iOS-PRIMO Message window for the sent Android-PRIMO-Ping$")
	public void i_am_checking_in_the_Android_PRIMO_user_iOS_PRIMO_Message_window_for_the_sent_Android_PRIMO_Ping(String andUsername) throws Throwable {
	    
		try{
			
			boolean IMiOSPingpresence = iosprimo.findElement(By.xpath("//*[contains(text(), 'qateam_myth pinged you')]")).isDisplayed();
		
			if(IMiOSPingpresence){
			
				System.out.println("Ping sent by Android User " + andUsername + " received successfully");
		
			}
		}
		
			catch(org.openqa.selenium.NoSuchElementException e){
		
				System.out.println(e);
				System.out.println("Ping sent by Android User " + andUsername + " not received");
		
			}
		
	}


/*Android to iOS File Sharing Check method*/
	
	@Then("^I am checking in the Android-PRIMO user \"([^\"]*)\" iOS-PRIMO Message window for the sent Android-PRIMO-File$")
	public void i_am_checking_in_the_Android_PRIMO_user_iOS_PRIMO_Message_window_for_the_sent_Android_PRIMO_File(String andUsername) throws Throwable {
	    
		try{
			
			boolean IMiOSFilepresence = iosprimo.findElement(By.xpath("//device/view/window[1]/table[2]/cell[3]/textfield[1]")).isDisplayed();
		
			if(IMiOSFilepresence){
			
				System.out.println("File sent by Android User " + andUsername + " received successfully");
		
			}
	
		}
		
			catch(org.openqa.selenium.NoSuchElementException e){
		
				System.out.println(e);
				System.out.println("File sent by Android user " + andUsername + " not received");
		
			}
		
	}

	
	
/*iOS to Android P2P Audio Call methods*/
	
	@Given("^I am initiating a PtoP audio call to Android from iOS device$")
	public void i_am_initiating_a_PtoP_audio_call_to_Android_from_iOS_device() throws Throwable {
	    
		iosprimo.findElement(By.xpath("//*[@xPath='//device/view/window[1]/scrollview[1]/image[4]']")).click();
		System.out.println("ios Calling ");
		System.out.println("Android ringing");
		String andacceptaudiocall="C:\\Users\\Priya\\Desktop\\ultra\\Primo\\Primo\\Repository\\Android_AcceptCallImage.png";
		andvisprimo.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		andvisprimo.manageMobile().visualOptions().validationOptions().setThreshold(20);
		andvisprimo.manageMobile().visualOptions().selectOptions().setShift(MobileShiftOptions.NONE);
		andvisprimo.findElement(ByMobile.image(andacceptaudiocall)).click();
        System.out.println("Call established successful");
		System.out.println("Call going to end in 15sec");
		
	}

	@Then("^I am accepting the incoming PtoP audio call in Android device$")
	public void i_am_accepting_the_incoming_PtoP_audio_call_in_Android_device() throws Throwable {
	    
		iosprimo.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		iosprimo.findElement(By.name("EndCall")).click();
		
	}

	@And("^I am disconnecting the initiated PtoP audio call in iOS device$")
	public void i_am_disconnecting_the_initiated_PtoP_audio_call_in_iOS_device() throws Throwable {
	    
		boolean ContactCall=iosprimo.findElement(By.xpath("//*[@xPath='//device/view/window[1]/scrollview[1]/image[4]']")).isEnabled();
		if(ContactCall)
			System.out.println("Call ended successfully");
	
		else
			System.out.println("Call not ended successfully");
		
	}

	
	
/*Android to iOS P2P Audio Call methods*/
	
	@Given("^I am initiating a PtoP audio call to iOS from Android device$")
	public void i_am_initiating_a_PtoP_audio_call_to_iOS_from_Android_device() throws Throwable {
	    
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_options_open")).click();
		System.out.println("Clicked on the options button in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_audio_call")).click();
		System.out.println("Clicked on the Audio Call button in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		System.out.println("Android making a P2P audio call to iOS");
		
		//String Android_video_CallImage="C:\\Users\\Prasanna\\workspace\\PRIMO\\src\\main\\Repository\\Android_initiateaudiocallImage.png";
		//andvisprimo.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//andvisprimo.manageMobile().visualOptions().validationOptions().setThreshold(20);
		//andvisprimo.manageMobile().visualOptions().selectOptions().setShift(MobileShiftOptions.NONE);
		//andvisprimo.findElement(ByMobile.image(Android_video_CallImage)).click();
			
	}

	@Then("^I am accepting the incoming PtoP audio call in iOS device$")
	public void i_am_accepting_the_incoming_PtoP_audio_call_in_iOS_device() throws Throwable {
	    
		iosprimo.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		iosprimo.findElement(By.name("AcceptCall")).click();
		System.out.println("Android Audio call connected successfully");
		System.out.println("Android Audio call going to end in 20 sec");
		
		Thread.sleep(20000);
		
		//iosprimo.findElement(By.name("EndCall")).click();
		//System.out.println("Android Audio call disconnected successfully");
		
	}

	@And("^I am disconnecting the initiated PtoP audio call in Android device$")
	public void i_am_disconnecting_the_initiated_PtoP_audio_call_in_Android_device() throws Throwable {
	    
		String Android_End_CallImage="C:\\Users\\Prasanna\\workspace\\PRIMO\\src\\main\\Repository\\Android_endcallImage.png";
		andvisprimo.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		andvisprimo.manageMobile().visualOptions().validationOptions().setThreshold(20);
		andvisprimo.manageMobile().visualOptions().selectOptions().setShift(MobileShiftOptions.NONE);
		andvisprimo.findElement(ByMobile.image(Android_End_CallImage)).click();
		System.out.println("Audio Call disconnected successfully");
		
	}

	
	
/*iOS to Android P2P Video Call methods*/
	
	@Given("^I am initiating a PtoP video call to Android from iOS device$")
	public void i_am_initiating_a_PtoP_video_call_to_Android_from_iOS_device() throws Throwable {
	    
		iosprimo.findElement(By.xpath("//*[@xPath='//device/view/window[1]/scrollview[1]/image[6]']")).click();
		System.out.println("ios Calling ");
		System.out.println("Android ringing");
		String andacceptvideocall="C:\\Users\\Priya\\Desktop\\ultra\\Primo\\Primo\\Repository\\Android_acceptvideocallImage.png";
		andvisprimo.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		andvisprimo.manageMobile().visualOptions().validationOptions().setThreshold(20);
		andvisprimo.manageMobile().visualOptions().selectOptions().setShift(MobileShiftOptions.NONE);
		andvisprimo.findElement(ByMobile.image(andacceptvideocall)).click();
        System.out.println("Call established successful");
		System.out.println("Call going to end in 15sec");
		
	}

	@Then("^I am accepting the incoming PtoP video call in Android device$")
	public void i_am_accepting_the_incoming_PtoP_video_call_in_Android_device() throws Throwable {
	    
		iosprimo.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		iosprimo.findElement(By.name("EndCall")).click();
		
	}

	@And("^I am disconnecting the initiated PtoP video call in iOS device$")
	public void i_am_disconnecting_the_initiated_PtoP_video_call_in_iOS_device() throws Throwable {
	    
		boolean ContactCall=iosprimo.findElement(By.xpath("//*[@xPath='//device/view/window[1]/scrollview[1]/image[4]']")).isEnabled();
		if(ContactCall)
			System.out.println("Call ended successfully");
		else
			System.out.println("Call not ended successfully");
		
	}

	
	
/*Android to iOS P2P Video Call methods*/
	
	@Given("^I am initiating a PtoP video call to iOS from Android device$")
	public void i_am_initiating_a_PtoP_video_call_to_iOS_from_Android_device() throws Throwable {
	    
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_options_open")).click();
		System.out.println("Clicked on the options button in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_video_call")).click();
		System.out.println("Clicked on the Video Call button in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		System.out.println("Android making a P2P Video call to iOS");
		
		//String Android_video_CallImage="C:\\Users\\Priya\\Desktop\\ultra\\Primo\\Primo\\Repository\\Android_initiatevideocallImage.png";
		//andvisprimo.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//andvisprimo.manageMobile().visualOptions().validationOptions().setThreshold(20);
		//andvisprimo.manageMobile().visualOptions().selectOptions().setShift(MobileShiftOptions.NONE);
		//andvisprimo.findElement(ByMobile.image(Android_video_CallImage)).click();
		
	}

	@Then("^I am accepting the incoming PtoP video call in iOS device$")
	public void i_am_accepting_the_incoming_PtoP_video_call_in_iOS_device() throws Throwable {
	    
		//iosprimo.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		iosprimo.findElement(By.name("AcceptCall")).click();
		System.out.println("Android video call connected successfully");
		System.out.println("Android video call going to end in 20 sec");
		
		Thread.sleep(20000);
		
		iosprimo.findElement(By.name("EndCall")).click();
		System.out.println("Android Video call disconnected successfully");
		
	}

	@And("^I am disconnecting the initiated PtoP video call in Android device$")
	public void i_am_disconnecting_the_initiated_PtoP_video_call_in_Android_device() throws Throwable {
	    
		String Android_End_CallImage="C:\\Users\\Priya\\Desktop\\ultra\\Primo\\Primo\\Repository\\Android_endcallImage.png";
		andvisprimo.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		andvisprimo.manageMobile().visualOptions().validationOptions().setThreshold(20);
		andvisprimo.manageMobile().visualOptions().selectOptions().setShift(MobileShiftOptions.NONE);
		andvisprimo.findElement(ByMobile.image(Android_End_CallImage)).click();
		System.out.println("Call ended successfully");
		
	}


	
/*iOS SMS methods*/
	
	@Given("^I am navigating to the Android-Messages application$")
	public void i_am_navigating_to_the_Android_Messages_application() throws Throwable {
		
		iosdevice.home();
		System.out.println("Now in iOS device's home screen");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		anddevice.home();
		System.out.println("Now in Android device's home screen");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo = anddevice.getNativeDriver("Messages");
		andprimo.open();
		System.out.println("Navigated to Android-Messages Application");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}
	
	
	@And("^I am deleting the chat history of iOS Inbound User \"([^\"]*)\" in Android-Messages application$")
	public void i_am_deleting_the_chat_history_of_iOS_Inbound_User_in_Android_Messages_application(String iOSInboundMSISDN) throws Throwable {
	    
		try {
		
		boolean iOSInboundMSISDNpresent = andprimo.findElement(By.xpath("//*[text()=\"+12675102730\"]")).isDisplayed();	
		
		if (iOSInboundMSISDNpresent){
			
		andprimo.findElement(By.xpath("//*[text()=\"More\"]")).click();
		System.out.println("Clicked on the More in Message Window");
		
		andprimo.findElement(By.xpath("//*[text()=\"Delete\"]")).click();
		System.out.println("Clicked on the Delete in Message Window");
		
		andprimo.findElement(By.id("com.android.mms:id/select_all_checkbox")).click();
		System.out.println("Checkbox to delete All messages checked");
		
		andprimo.findElement(By.id("com.android.mms:id/delete")).click();
		System.out.println("Clicked on the Delete in Message Window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.xpath("//*[text()=\"Delete\"]")).click();
		System.out.println("Confirmed alert message to delete all messages");
		
		  }
		
		}
		
	catch(org.openqa.selenium.NoSuchElementException e){

		System.out.println(e);
		System.out.println("No message history available in Android-Messages application to delete");
		
		}

	}
		
		
	@Then("^I am navigating to the iOS-PRIMO Message Window from the left slide out main menu$")
	public void i_am_navigating_to_the_iOS_PRIMO_Message_Window_from_the_left_slide_out_main_menu() throws Throwable {
	    
		iosprimo = iosdevice.getNativeDriver("Primo");
		iosprimo.open();
		System.out.println("Navigated to iOS-PRIMO Application");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Menu")).click();
		System.out.println("Clicked on iOS-PRIMO Navigation icon");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Contacts")).click();
		System.out.println("Now in iOS-PRIMO Contacts Tab");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@And("^I am searching and navigating to iOS Outbound User \"([^\"]*)\" in iOS-PRIMO Message Window$")
	public void i_am_searching_and_navigating_to_iOS_Outbound_User_in_iOS_PRIMO_Message_Window(String iOSOutboundMSISDN) throws Throwable {
	    
		iosprimo.findElement(By.name("All")).click();
		System.out.println("Navigated to iOS-PRIMO-Contacts-All tab");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Search")).sendKeys("Samsung Galaxy S6");
		System.out.println("Searched iOS Outbound user : " + iOSOutboundMSISDN);
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Samsung Galaxy S6")).click();
		System.out.println("Now in selected iOS Outbound user : " + iOSOutboundMSISDN  + " iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@Then("^I am deleting the chat history of iOS Outbound User \"([^\"]*)\" in iOS-PRIMO Message Window$")
	public void i_am_deleting_the_chat_history_of_iOS_Outbound_User_in_iOS_PRIMO_Message_Window(String iOSOutboundMSISDN) throws Throwable {
	    
		iosprimo.findElement(By.name("ChatOptions")).click();
		System.out.println("Clicked on the options button in iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("ChatOptionMore")).click();
		System.out.println("Clicked on the more options button in iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Delete History")).click();
		System.out.println("Selected delete history in iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		System.out.println("Deleted iOS Outbound User : " + iOSOutboundMSISDN + " chat history in iOS-PRIMO chat window successfully");

		iosprimo.findElement(By.name(iOSOutboundMSISDN)).click();
		System.out.println("Now in selected iOS Outbound User : " + iOSOutboundMSISDN  + " iOS-PRIMO chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);

	}


	@When("^I am sending the iOS Outbound SMS \"([^\"]*)\" to the iOS Outbound User \"([^\"]*)\"$")
	public void i_am_sending_the_iOS_Outbound_SMS_to_the_iOS_Outbound_User(String iOSOutboundSMS, String iOSOutboundMSISDN) throws Throwable {
	 
		iosprimo.findElement(By.xpath("//*[@value=\"Enter SMS message\"]")).sendKeys(iOSOutboundSMS);
		System.out.println("Entered the iOS Outbound SMS : " + iOSOutboundSMS + " to be sent in the recipient iOS Outbound Contact : " + iOSOutboundMSISDN + " iOS-Primo Message window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("ChatSend")).click();
		System.out.println("Successfully sent the iOS Outbound SMS : " + iOSOutboundSMS + " to iOS Outbound Contact : " + iOSOutboundMSISDN );
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("NavigationBarBack")).click();
		System.out.println("Clicked on the back button in iOS Outbound Contact : " + iOSOutboundMSISDN + " iOS-PRIMO-chat window");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		iosprimo.findElement(By.name("Cancel")).click();
		System.out.println("Clicked on the Cancel button in iOS-PRIMO");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
	
	}

	
	
	@And("^I am checking the iOS Inbound User \"([^\"]*)\" in Android-Message window for the sent iOS Outbound SMS \"([^\"]*)\"$")
	public void i_am_checking_the_iOS_Inbound_User_in_Android_Message_window_for_the_sent_iOS_Outbound_SMS(String iOSInboundMSISDN, String iOSOutboundSMS ) throws Throwable {
	    
		try{
			
			boolean iOSInboundMSISDNpresence = andprimo.findElement(By.xpath("//*[text()=\"+12675102730\"]")).isDisplayed();
			
			if(iOSInboundMSISDNpresence){
			
				andprimo.findElement(By.xpath("//*[text()=\"+12675102730\"]")).click();
				System.out.println("Clicked on iOS Inbound MSISDN : " + iOSInboundMSISDN + " in Android-Messages application" );
				andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
				
				andprimo.findElement(By.xpath("//*[text()=\"iOS Outbound Message\"]")).isDisplayed();
				System.out.println("iOS Outbound SMS : " + iOSOutboundSMS + " sent by iOS Inbound Contact : " + iOSInboundMSISDN + " received successfully");
				andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
				
			}
	
		}
		
			catch(org.openqa.selenium.NoSuchElementException e){
		
				System.out.println(e);
				System.out.println("iOS Outbound SMS : " + iOSOutboundSMS + " sent by iOS Inbound Contact : " + iOSInboundMSISDN + " not received");
		
			}
		
	}
	
	
	@When("^I am sending the iOS Inbound SMS \"([^\"]*)\" to the iOS Inbound User \"([^\"]*)\"$")
	public void i_am_sending_the_iOS_Inbound_SMS_to_the_iOS_Inbound_User(String iOSInboundSMS, String iOSInboundMSISDN) throws Throwable {
	 
		andprimo.findElement(By.id("com.android.mms:id/floating_action_button")).click();
		System.out.println("Clicked on the compose icon in Android-Messages window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.android.mms:id/recipients_editor_to")).sendKeys(iOSInboundMSISDN);
		System.out.println("Entered the iOS-PRIMO Inbound User : " + iOSInboundMSISDN);
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.android.mms:id/editor_body")).sendKeys(iOSInboundSMS);
		System.out.println("Entered the iOS-PRIMO Inbound Message : " + iOSInboundSMS);
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.android.mms:id/send_button")).click();
		System.out.println("Clicked on the SEND button");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@And("^I am checking the iOS Outbound User \"([^\"]*)\" in iOS-PRIMO Message window for the sent iOS Inbound SMS \"([^\"]*)\"$")
	public void i_am_checking_the_iOS_Outbound_User_in_iOS_PRIMO_Message_window_for_the_sent_iOS_Inbound_SMS(String iOSOutboundMSISDN, String iOSInboundSMS) throws Throwable {
	    
		try{
			
			boolean iOSInboundSMSpresence = iosprimo.findElement(By.name(iOSInboundSMS)).isDisplayed();
		
			if(iOSInboundSMSpresence){
			
				System.out.println("iOS Inbound SMS : " + iOSInboundSMS + " sent by iOS Outbound Contact : " + iOSOutboundMSISDN + " received successfully");
		
			}
	
		}
		
			catch(org.openqa.selenium.NoSuchElementException e){
		
				System.out.println(e);
				System.out.println("iOS Inbound SMS : " + iOSInboundSMS + " sent by iOS Outbound Contact : " + iOSOutboundMSISDN + " not received");
		
			}
		
	}
	
	
	
/*Android SMS methods*/
	
	@Given("^I am navigating to Android-Messages application$")
	public void i_am_navigating_to_Android_Messages_application() throws Throwable {
		
		//anddevice.home();
		//System.out.println("Now in Android device's home screen");
		//andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo = anddevice.getNativeDriver("Messages");
		andprimo.open();
		System.out.println("Navigated to Android-Messages Application");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}
	

	@And("^I am deleting the chat history of Android Inbound User \"([^\"]*)\" in Android-Messages application$")
	public void i_am_deleting_the_chat_history_of_Android_Inbound_User_in_Android_Messages_application(String andInboundMSISDN) throws Throwable {
	    
		try {
			
			boolean andInboundMSISDNpresent = andprimo.findElement(By.xpath("//*[text()=\"+12675102730\"]")).isDisplayed();	
			
			if (andInboundMSISDNpresent){
				
			andprimo.findElement(By.xpath("//*[text()=\"More\"]")).click();
			System.out.println("Clicked on the More in Message Window");
			
			andprimo.findElement(By.xpath("//*[text()=\"Delete\"]")).click();
			System.out.println("Clicked on the Delete in Message Window");
			
			andprimo.findElement(By.id("com.android.mms:id/select_all_checkbox")).click();
			System.out.println("Checkbox to delete All messages checked");
			
			andprimo.findElement(By.id("com.android.mms:id/delete")).click();
			System.out.println("Clicked on the Delete in Message Window");
			andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			
			andprimo.findElement(By.xpath("//*[text()=\"Delete\"]")).click();
			System.out.println("Confirmed alert message to delete all messages");
			
			  }
			
			}
			
		catch(org.openqa.selenium.NoSuchElementException e){

			System.out.println(e);
			System.out.println("No message history available in Android-Messages application to delete");
			
			}
		
	}

	
	@Then("^I am navigating to the Android-PRIMO Message Window from the left slide out main menu$")
	public void i_am_navigating_to_the_Android_PRIMO_Message_Window_from_the_left_slide_out_main_menu() throws Throwable {
	   
		andprimo = anddevice.getNativeDriver("Primo");
		andprimo.open();
		System.out.println("Navigated to Android-PRIMO Application");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.xpath("//*[@class='android.widget.ImageButton']")).click();
		System.out.println("Clicked on Android-PRIMO Navigation icon");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.linkText("Contacts")).click();
		System.out.println("Now in Android-PRIMO Contacts Tab");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@And("^I am searching and navigating to Android Outbound User \"([^\"]*)\" in Android-PRIMO Message Window$")
	public void i_am_searching_and_navigating_to_Android_Outbound_User_in_Android_PRIMO_Message_Window(String andOutboundMSISDN) throws Throwable {
	    
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/all_contacts_label")).click();
		System.out.println("Navigated to Android-PRIMO-Contacts-All tab");
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/menu_search")).click();
		System.out.println("Clicked on Search icon in Contacts tab ");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/search_src_text")).sendKeys(andOutboundMSISDN);
		System.out.println("Searched Android Outbound user : " + andOutboundMSISDN);
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/text1")).click();
		System.out.println("Now in selected Android Outbound user : " + andOutboundMSISDN  + " Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/txt_phone")).click();
		System.out.println("Selected MSISDN number in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@Then("^I am deleting the chat history of Android Outbound User \"([^\"]*)\" in Android-PRIMO Message Window$")
	public void i_am_deleting_the_chat_history_of_Android_Outbound_User_in_Android_PRIMO_Message_Window(String andOutboundMSISDN) throws Throwable {
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_options_open")).click();
		System.out.println("Clicked on the options button in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_more_options")).click();
		System.out.println("Clicked on the more options button in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/delete_history_textview")).click();
		System.out.println("Selected delete history in Android-PRIMO chat window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		System.out.println("Deleted Android Outbound User : " + andOutboundMSISDN + " chat history in Android-PRIMO chat window successfully");

	}

	
	@When("^I am sending the Android Outbound SMS \"([^\"]*)\" to the Android Outbound User \"([^\"]*)\"$")
	public void i_am_sending_the_Android_Outbound_SMS_to_the_Android_Outbound_User(String andOutboundSMS, String andOutboundMSISDN) throws Throwable {
	    
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/edit_text_message")).sendKeys(andOutboundSMS);
		System.out.println("Entered the Android Outbound SMS : " + andOutboundSMS + " to be sent in the recipient Android Outbound Contact : " + andOutboundMSISDN + " Android-Primo Message window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.primo.mobile.android.app:id/button_send_sms")).click();
		System.out.println("Successfully sent the Android Outbound SMS : " + andOutboundSMS + " to Android Outbound Contact : " + andOutboundMSISDN );
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@And("^I am checking the Android Inbound User \"([^\"]*)\" in Android-Message window for the sent Android Outbound SMS \"([^\"]*)\"$")
	public void i_am_checking_the_Android_Inbound_User_in_Android_Message_window_for_the_sent_Android_Outbound_SMS(String andInboundMSISDN, String andOutboundSMS) throws Throwable {
	    
		try{
			
			boolean andInboundMSISDNpresence = andprimo.findElement(By.xpath("//*[text()=\"+15189539661\"]")).isDisplayed();
			
			if(andInboundMSISDNpresence){
			
				andprimo.findElement(By.xpath("//*[text()=\"+15189456429\"]")).click();
				System.out.println("Clicked on Android Inbound MSISDN : " + andInboundMSISDN + " in Android-Messages application" );
				andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
				
				andprimo.findElement(By.xpath("//*[text()=\"and_Outbound_Message\"]")).isDisplayed();
				System.out.println("Android Outbound SMS : " + andOutboundSMS + " sent by Android Inbound Contact : " + andInboundMSISDN + " received successfully");
				andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
				
			}
	
		}
		
			catch(org.openqa.selenium.NoSuchElementException e){
		
				System.out.println(e);
				System.out.println("Android Outbound SMS : " + andOutboundSMS + " sent by Android Inbound Contact : " + andInboundMSISDN + " not received");
		
			}
		
	}

	
	@When("^I am sending the Android Inbound SMS \"([^\"]*)\" to the Android Inbound User \"([^\"]*)\"$")
	public void i_am_sending_the_Android_Inbound_SMS_to_the_Android_Inbound_User(String andInboundSMS, String andInboundMSISDN) throws Throwable {
	   
		andprimo.findElement(By.id("com.android.mms:id/floating_action_button")).click();
		System.out.println("Clicked on the compose icon in Android-Messages window");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.android.mms:id/recipients_editor_to")).sendKeys(andInboundMSISDN);
		System.out.println("Entered the Android-PRIMO Inbound User : " + andInboundMSISDN);
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.android.mms:id/editor_body")).sendKeys(andInboundSMS);
		System.out.println("Entered the Android-PRIMO Inbound Message : " + andInboundSMS);
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		andprimo.findElement(By.id("com.android.mms:id/send_button")).click();
		System.out.println("Clicked on the SEND button");
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@And("^I am checking the Android Outbound User \"([^\"]*)\" in Android-PRIMO Message window for the sent Android Inbound SMS \"([^\"]*)\"$")
	public void i_am_checking_the_Android_Outbound_User_in_Android_PRIMO_Message_window_for_the_sent_Android_Inbound_SMS(String andOutboundMSISDN, String andInboundSMS) throws Throwable {
	 
		try{
			
			boolean andInboundSMSpresence = andprimo.findElement(By.xpath("//*[text()=\"and_Inbound_Message\"]")).isDisplayed();
		
			if(andInboundSMSpresence){
			
				System.out.println("Android Inbound SMS : " + andInboundSMS + " sent by Android Outbound Contact : " + andOutboundMSISDN + " received successfully");
		
			}
	
		}
		
			catch(org.openqa.selenium.NoSuchElementException e){
		
				System.out.println(e);
				System.out.println("Android Inbound SMS : " + andInboundSMS + " sent by Android Outbound Contact : " + andOutboundMSISDN + " not received");
		
			}
	
	}
	
	

/*iOS Edit Profile methods*/
	
	@Given("^I am navigating to the iOS-Primo My Account Window from the left slide out main menu$")
	public void i_am_navigating_to_the_iOS_Primo_My_Account_Window_from_the_left_slide_out_main_menu() throws Throwable {
	    
		//iosdevice.home();
		//iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		//iosprimo = iosdevice.getNativeDriver("Primo");
		//iosprimo.open();
		//iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		iosprimo.findElement(By.name("My Account")).click();
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@And("^I am navigating to iOS-Primo Edit Profile page$")
	public void i_am_navigating_to_iOS_Primo_Edit_Profile_page() throws Throwable {
	   
		iosprimo.findElement(By.name("Edit Profile")).click();
		iosprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@Then("^I am checking the iOS-Primo Edit Profile details-Name, Email ID, MSISDN, Hometown and Location$")
	public void i_am_checking_the_iOS_Primo_Edit_Profile_details_Name_Email_ID_MSISDN_Hometown_and_Location() throws Throwable {
	    
		try{
			
			if(iosprimo.findElement(By.name("Arun Prasanna")).isDisplayed())		{
				
				System.out.println("Expected iOS-Name is present");
				
			}
		
		}
				
		catch(org.openqa.selenium.NoSuchElementException e){
					
					System.out.println(e);
					System.out.println("Expected iOS-Name is absent");
			
		}
		
		
		try{
			
			if(iosprimo.findElement(By.name("arunp.kuma@primo.me")).isDisplayed())		{
				
				System.out.println("Expected iOS-Email ID is present");
				
			}
		
		}
		
		catch(org.openqa.selenium.NoSuchElementException e){
					
					System.out.println(e);
					System.out.println("Expected iOS-Email ID is absent");
			
		}
		
		
		try{
			
			if(iosprimo.findElement(By.name("919600454709")).isDisplayed())		{
				
				System.out.println("Expected iOS-MSISDN is present");
				
			}
			
		}
				
		catch(org.openqa.selenium.NoSuchElementException e){
					
					System.out.println(e);
					System.out.println("Expected iOS-MSISDN is absent");
			
		}
		
		
		try{
			
			if(iosprimo.findElement(By.name("Madurai, IN")).isDisplayed())		{
				
				System.out.println("Expected iOS-Hometown is present");
				
			}
		
		}
				
		catch(org.openqa.selenium.NoSuchElementException e){
					
					System.out.println(e);
					System.out.println("Expected iOS-Hometown is absent");
			
		}
		
				
		try{
				
			if(iosprimo.findElement(By.name("Tiruvanmiyur, Chennai, Chennai, Tamil Nadu, IN")).isDisplayed())		{
				
				System.out.println("Expected iOS-Location is present");
				
			}
		
		}	
		
		catch(org.openqa.selenium.NoSuchElementException e){
					
					System.out.println(e);
					System.out.println("Expected iOS-Location is absent");
			
		}
		
	}


	
/*Android Edit Profile methods*/
	
	@Given("^I am navigating to the Android-Primo My Account Window from the left slide out main menu$")
	public void i_am_navigating_to_the_Android_Primo_My_Account_Window_from_the_left_slide_out_main_menu() throws Throwable {
	    
		//anddevice.home();
		//andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		//andprimo = anddevice.getNativeDriver("Primo");
		//andprimo.open();
		//andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		andprimo.findElement(By.name("My Account")).click();
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@And("^I am navigating to Android-Primo Edit Profile page$")
	public void i_am_navigating_to_Android_Primo_Edit_Profile_page() throws Throwable {
	    
		andprimo.findElement(By.name("Edit Profile")).click();
		andprimo.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

	
	@Then("^I am checking the Android-Primo Edit Profile details-Name, Email ID, MSISDN, Hometown and Location$")
	public void i_am_checking_the_Android_Primo_Edit_Profile_details_Name_Email_ID_MSISDN_Hometown_and_Location() throws Throwable {
	 
		try{
			
			if(andprimo.findElement(By.xpath("//*[text()=\"Mythili Panekatt\"]")).isDisplayed())		{
				
				System.out.println("Expected Android-Name is present");
				
			}
		
		}
				
		catch(org.openqa.selenium.NoSuchElementException e){
					
					System.out.println(e);
					System.out.println("Expected Android-Name is absent");
			
		}
		
		
		try{
			
			if(andprimo.findElement(By.xpath("//*[text()=\"mythili@ultra.me\"]")).isDisplayed())		{
				
				System.out.println("Expected Android-Email ID is present");
				
			}
		
		}
		
		catch(org.openqa.selenium.NoSuchElementException e){
					
					System.out.println(e);
					System.out.println("Expected Android-Email ID is absent");
			
		}
		
		
		try{
			
			if(andprimo.findElement(By.xpath("//*[text()=\"919597067036\"]")).isDisplayed())		{
				
				System.out.println("Expected Android-MSISDN is present");
				
			}
			
		}
				
		catch(org.openqa.selenium.NoSuchElementException e){
					
					System.out.println(e);
					System.out.println("Expected Android-MSISDN is absent");
			
		}
		
		
		try{
			
			if(andprimo.findElement(By.xpath("//*[text()=\"Kollam, IN\"]")).isDisplayed())		{
				
				System.out.println("Expected Android-Hometown is present");
				
			}
		
		}
				
		catch(org.openqa.selenium.NoSuchElementException e){
					
					System.out.println(e);
					System.out.println("Expected Android-Hometown is absent");
			
		}
		
				
		try{
				
			if(andprimo.findElement(By.xpath("//*[text()=\"Velacheri, Chennai, Tamil Nadu, IN\"]")).isDisplayed())		{
				
				System.out.println("Expected Android-Location is present");
				
			}
		
		}	
		
		catch(org.openqa.selenium.NoSuchElementException e){
					
					System.out.println(e);
					System.out.println("Expected Android-Location is absent");
			
		}	
	
	}
	
}