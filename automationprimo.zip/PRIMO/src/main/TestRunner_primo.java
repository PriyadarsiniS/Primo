package main;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features={"src//main//PrimoFunctions_primo.feature"},
						//{"src//main//Functionalities_primo.feature"},

						//tags = {"iOSSignIn"},
				format = {"pretty", "html:target/cucumber-htmlreport"})

	public class TestRunner_primo {	
	
}